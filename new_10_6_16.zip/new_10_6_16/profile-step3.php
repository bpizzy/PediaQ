<?php require "function.php";CheckLogin(); getHeader();// load main function file and then load header ?>

<?php
	
	if(isset($_POST["payment_method_nonce"]))
	{
	  	 
	        $data = array(
			"token" 	=> getUserToken(),
			"paymentNonce"  => $_POST["payment_method_nonce"],
			"isDefault"     => 1
		);
		$url  = "api/payment/add";
		$post = json_decode(PostData($url,$data)); 
	 	if($post->success==1)
		{
			$_SESSION['success'] = "Payment method is Saved";
			$_SESSION['actual_payment_token'] = $post->paymentMethod->paymentToken;
			redirect("profile-step4.php");	
		}
		else
		{
			$_SESSION['error'] = $post->errors->message;
		}
		redirect("profile-step4.php");	
		 
	}


 
?>
<div class="container">

 
<div class="row">

<h3 class="form-head">Payment Method<span><b class="steps">Step 3 of 5</b></span></h3>
 
<div class="col-md-3"></div>

<div class="col-md-6">

 

	
<form class="add-patient-form"   id="checkout" method="post">
  <div id="payment-form"></div>
      <div class="form-group">
      <p class="profile4-charged">This payment method will only be charged when PediaQ Pediatric specialist visits the patient.<b><i><font color="black"> No charged for phone consulatation</font></i></b></p>
	  </div>
	  <div class="form-group">
       <button type="submit" name="submit"  class="btn btn-info next">Next</button><button type="button" class="btn btn-info back"  onclick="window.location.href='profile-step2.php'">Back</button>
      </div>
</form>

<div class="col-md-12"><br> 

</div> 

</div>

<div class="col-md-3"></div>
</div>
</div>


<?php getFooter();?>
<script>
$("document").ready(function(){
   	$(".addchild").click(function(){
 		 var flag 	= 0;
		 var error      = "";
         var name 	= $("#cardnumber").val();
		 var birthmonth = $("#month").val();
		 var birthyear  = $("#year").val();
	
		
		if(name=="")
		{
			error+="Please Enter Firstname & Lastname<br>";
			flag++;		
		}
		if(name=="" && (birthmonth=="" || birthyear=="") )
		{
			error="Please fill complete form<br>";
			flag++;
		}
		
		/** if error **/
		if(flag!=0)
		{
			$("#result").html("<div class='warning'>"+error+"</div>");
		}
		/** end **/

		/** if no error **/
		if(flag==0)
		{
			var dob = birthyear+"-"+birthmonth;
			$("#result").html("<div class='loading'><img src='images/loading.gif'></div>");
			$.ajax({
				url: 'function.php',
				type: 'post',
				dataType:'text',
				data: {function_name:'addChildajax',name: name,dob:dob},
				success: function(text) {
				$("#result").html(text);
		
				},
			
			});

			
		}
		/** end **/

        });

	 
});
</script>



<script src="https://js.braintreegateway.com/js/braintree-2.22.2.min.js"></script>
<script>
// We generated a client token for you so you can test out this code
// immediately. In a production-ready integration, you will need to
// generate a client token on your server (see section below).
var clientToken = "<?php echo getPaymentToken();?>";

braintree.setup(clientToken, "dropin", {
  container: "payment-form"
});
</script>
