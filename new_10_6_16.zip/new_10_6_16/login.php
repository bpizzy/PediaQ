<?php require "function.php";isLogin(); getHeader();// load main function file and then load header ?>

<?php

	if(isset($_POST['submit']))
	{

		$flag = 0;
	  	$field = $_POST['register-email'];
	  	/** email check **/
		if(preg_match("/\@/i",$field))
		{
		    $data = array(
		  	 'email'      => $_POST['register-email'],
		 	 'password'   => $_POST['register-password']  	
		    );

 		$url = "api/auth/login";
		$return = json_decode(PostData($url,$data));// call login Api
			
			/** error **/				
			if(!$return->success)
			{
			   echo "<div class='warning container'>".$return->errors->message."</div>";		
			}
			/** end **/	

			/** error **/				
			if($return->success)
			{
		           $_SESSION['user_token'] =  $return->token;
			   redirect("dashboard.php");
			}
			/** end **/
			$flag++;	
		}
	   	/** end **/


		/** email check **/
		if(preg_match("/\-/i",$field) or preg_match("/\+/i",$field))
		{
		     if(preg_match("/\+/i",$field))
		     {
			 $number = $_POST['register-email'];
		     }
		     else
		     {
          		$number = "+1 ".$_POST['register-email'];
                     }
		     
		     $data   = array(
		  	 'phone'      => $number,
		 	 'password'   => $_POST['register-password']  	
		     );

 		     $url = "api/auth/login";
		     $return = json_decode(PostData($url,$data));// call login Api
		 
			 
			/** error **/				
			if(!$return->success)
			{
			   echo "<div class='warning container'>".$return->errors->message."</div>";		
			}
			/** end **/	

			/** error **/				
			if($return->success)
			{
		           $_SESSION['user_token'] =  $return->token;
			   redirect("dashboard.php");
			}
			/** end **/	
			$flag++;
		}
	   	/** end **/

		if($flag==0)
		{
			 echo "<div class='warning container'>Please enter correct Email/Mobile # format</div>";
		}

		 
	}

?>
<div class="container">

 
<div class="row">

<h3 class="form-head">Welcome back!<span><i class="header-i">If you have an iPhone, please make the request on <a target="_blank" href="https://itunes.apple.com/us/app/pediaq/id973830641" style="text-decoration: underline !important;">your PediaQ app</a></i> </span></h3>
 
<div class="col-md-3"></div>

<div class="col-md-6">

<form class="add-patient-form"  method="post">
<div class="form-group mobile-main">
        <label for="mobile">Mobile # / Email</label>
        <input type="text" name="register-email" placeholder="Enter your Mobile # or Email" autocomplete="off" id="mobile" class="form-control">
      </div>

<div class="form-group password-main">
        <label for="fullname">Password</label>
        <input type="password"  name="register-password" autocomplete="off" placeholder="Enter your Password" id="password" class="form-control">
      </div>
 
   <div class="form-group">
      <a class="pull-right forget" href="forgetpassword.php" style="text-decoration: underline !important;">Forget Password</a>
      </div>


            <div class="clear"> </div>
      
      <div class="form-group">
       <button type="submit" name="submit"  class="btn btn-info next">Sign In</button><button type="button" class="btn btn-info back">Back</button>
      </div>
</form>

<div class="col-md-12"><br> 

</div> 

</div>

<div class="col-md-3"></div>
</div>
</div>


<?php getFooter();?>
<script src="js/jquery.maskedinput-1.3.js" type="text/javascript"></script>
<script>


$('#mobile').keyup(function(e) {

var unicode=e.keyCode? e.keyCode : e.charCode;

if( unicode >= 48 && unicode <= 57) {

var a = parseInt($(this).val().split("-"));

if($.isNumeric(a) && a!=0)
{
  	foo = $(this).val().split("-").join(""); // remove hyphens
 	foo = foo.match(new RegExp('.{1,4}$|.{1,3}', 'g')).join("-");
        $(this).val(foo);
}
}
else
{


}
});


</script>
<script>
$("document").ready(function(){
var flag  = 0;
var error = "";
	$(".next").click(function(){
	 flag  = 0;
         $(".red-text").remove();$(".warning").remove();
         var mobile = $("#mobile").val();
	 var password = $("#password").val();
	 	if(mobile=="")
   		{
                   $(".mobile-main").addClass("error-input");
                   $("<span class='red-text'>Enter mobile #</span>").insertAfter("#mobile");
		   flag++;		
		}
                else
                {
                   $(".mobile-main").removeClass("error-input"); 
                }
		if(password=="")
   		{
                   $(".password-main").addClass("error-input");
		   $("<p class='red-text'>Enter Password</p>").insertAfter("#password");
		   flag++;		
		}
                else
                {
                   $(".password-main").removeClass("error-input");
                }
                if(password.length<6 && password!="")
   		{
                   $(".password-main").addClass("error-input");
                   $("<p class='red-text'>Password must be at least 6 characters</p>").insertAfter("#password");
		   flag++;		
		}
		if(flag==0)
		{
		return true;		
		}
		else
		{
		return false;	
		}
				
	});
	
   	$(".back").click(function(){
		window.location.href="index.php";
	});
});
</script>

