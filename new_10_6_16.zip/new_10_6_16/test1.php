
<label for="email" id="email">Hey!</label>
<input id="email" name="email" type="text" class="required" /> 
<span class="msg error">You shall not pass!</span>
<span class="msg success">You can pass!</span>
<script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>

<script src="js/jquery.maskedinput-1.3.js" type="text/javascript"></script>

<style>
.msg {
    display: none;
}
.error {
    color: red;
}
.success {
    color: green;
}
</style>

<script>
var component = {
    input   : $('input[name="email"]'),
    mensage : {
        fields  : $('.msg'),
        success : $('.success'),
        error   : $('.error')
    }
},
    regex  = /^[a-z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)?@[a-z][a-zA-Z-0-9]*\.[a-z]+(\.[a-z]+)?$/;
	 regex1 = /^[0-9\b.,]+$/;


component.input.blur(function () {
    component.mensage.fields.hide();
    
	if(regex.test(component.input.val())){
		alert('hh');
		component.mensage.success.show();
	}
	if(regex1.test(component.input.val())) {
		//alert(component.input.val());
		aa = component.input.val();
		alert(aa);
		
		$("#email").mask("999-9999-9999");
}
});

</script>