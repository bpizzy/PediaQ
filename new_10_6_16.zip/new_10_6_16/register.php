<?php require "function.php"; isLogin();getHeader();// load main function file and then load header ?>

<?php

	if(isset($_POST['submit']))
	{
	    	if(preg_match("/\+/i",$_POST['register-email']))
	    	{
			$number = $_POST['register-email'];
           	}
	        else
	        {
          		$number = "+1 ".$_POST['register-email'];
                }
	    	$data = array(
	  	 'phone'      => $number,
	 	 'password'   => $_POST['register-password']  	
	    	);

 		$url = "api/auth/register";
		$return = json_decode(PostData($url,$data));// call login Api

	        if(count($return))
		{
		 

		   /** success **/
		   if(isset($return->success) and $return->success!="")
		   {
			$_SESSION['user_token'] =  $return->token; 
			$_SESSION['success']    = "Thank you for the Registration. Please Complete Your Profile.";
			redirect("profile-step1.php");
		   }	
		   /** end **/

		   /** error has been encounter **/
		   if(isset($return->errors))
		   {?>
		   <div class="warning container">
			<?php foreach($return->errors as $key=>$error)
			{
			   echo strtoUpper($key)."-".$error[0]."<br>"; 			
			}?>
		   </div>
		   <?php }
	           /** end **/		
		}

	}
?>
<div class="container">

<div id="page-result"></div> 
<div class="row">

<h3 class="form-head">Create Account <span><i class="header-i">If you have an iPhone, please make the request on <a target="_blank" href="https://itunes.apple.com/us/app/pediaq/id973830641" style="text-decoration: underline !important;">your PediaQ app</a></i> </span></h3>
 
<div class="col-md-3"></div>

<div class="col-md-6">

<form class="add-patient-form"  method="post">
<div class="form-group mobile-main">
        <label for="mobile">Mobile #</label>
        <input type="text" name="register-email" placeholder="Enter your Mobile #" autocomplete="off" id="mobile" class="form-control">
      </div>

<div class="form-group password-main">
        <label for="fullname">Password</label>
        <input type="password"  name="register-password" autocomplete="off" placeholder="Create your Password" id="password" class="form-control">
      </div>
 
 
            <div class="clear"> </div>
       <span class="small-span  pull-right">By creating an account, I accept PediaQ's <a href="http://www.pediaq.care/terms" target="_blank">Terms of Use</a> and <a href="http://www.pediaq.care/privacy" target="_blank">Privacy Policy</a> </span>
     <div class="clear"> </div>
      <div class="form-group">
       <button type="submit" name="submit" class="btn btn-info next">Create Account</button><button type="button" class="btn btn-info back">Back</button>
      </div>
</form>

<div class="col-md-12"><br> 

</div> 

</div>

<div class="col-md-3"></div>
</div>
</div>


<?php getFooter();?>
<script src="js/jquery.maskedinput-1.3.js" type="text/javascript"></script>
<script>
$('#mobile').keyup(function(e) {

var unicode=e.keyCode? e.keyCode : e.charCode;

if( unicode >= 48 && unicode <= 57) {

var a = parseInt($(this).val().split("-"));

if($.isNumeric(a) && a!=0)
{
  	foo = $(this).val().split("-").join(""); // remove hyphens
 	foo = foo.match(new RegExp('.{1,4}$|.{1,3}', 'g')).join("-");
        $(this).val(foo);
}
}
else
{

        // Filter non-digits from input value.
        this.value = this.value.replace(/\D/g, '');

}
});
</script>
<script>
$("document").ready(function(){

 
var flag  = 0;
var error = "";
	$(".next").click(function(){
         $(".red-text").hide();  
         $(".red-text").remove();$(".warning").remove();
	 flag  = 0;
         var mobile = $("#mobile").val();
	 var password = $("#password").val();
	 	if(mobile=="")
   		{
                   $(".mobile-main").addClass("error-input");
                   $("<span class='red-text'>Enter mobile #</span>").insertAfter("#mobile");
		   flag++;		
		}
                else
                {
                   $(".mobile-main").removeClass("error-input"); 
                }
		if(password=="")
   		{
                   $(".password-main").addClass("error-input");
		   $("<p class='red-text'>Enter Password</p>").insertAfter("#password");
		   flag++;		
		}
                else
                {
                   $(".password-main").removeClass("error-input");
                }
                if(password.length<6 && password!="")
   		{
                   $(".password-main").addClass("error-input");
                   $("<p class='red-text'>Password must be at least 6 characters</p>").insertAfter("#password");
		   flag++;		
		}
                
		 
		if(flag==0)
		{
                $(".password-main").removeClass("error-input");
		return true;		
		}
		else
		{
		return false;	
		}
				
	});
	
   	$(".back").click(function(){
		window.location.href="index.php";
	});
});
</script>

