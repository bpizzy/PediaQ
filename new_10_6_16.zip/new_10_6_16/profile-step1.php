<?php require "function.php";CheckLogin(); getHeader();// load main function file and then load header ?>

<?php
	$profile = getProfile("all");
?>

<div class="container">

 
<div class="row">

<h3 class="form-head">Complete Profile<span><b class="steps">Step 1 of 5</b></span></h3>
 
<div class="col-md-3"></div>

<div class="col-md-6">

<form class="add-patient-form"  method="post">
<div id="results"></div>
<div class="form-group name-main">
        <label for="mobile">Full Name</label>
        <input type="text" name="register-name" placeholder="Enter your first & last name" value="<?php if($profile->first_name){echo $profile->first_name.' '.$profile->last_name;}?>" autocomplete="off" id="register-name" class="form-control">
      </div>

<div class="form-group email-main">
        <label for="fullname">Email</label>
        <input type="email"  name="register-email" autocomplete="off" placeholder="Enter your email address" id="register-email" value="<?php echo $profile->email;?>" class="form-control">
      </div>
 
 <div class="clear"> </div>
      
      <div class="form-group">
       <button type="button" name="button"  class="btn btn-info next">Next</button><button type="button" class="btn btn-info back">Cancel</button>
      </div>
</form>

<div class="col-md-12"><br> 

</div> 

</div>

<div class="col-md-3"></div>
</div>
</div>


<?php getFooter();?>
<script>
$("document").ready(function(){
	 var flag  = 0;
	 var error = "";
	 $(".next").click(function(){
         flag  = 0;
         $(".red-text").remove();$(".warning").remove();$(".name-main,.email-main").removeClass("error-input");
	 $("#results").html("<div class='loading1'><img src='images/loading.gif'></div>");
         var full_name = $("#register-name").val();
	 var email = $("#register-email").val();
	 	if(full_name=="")
   		{
		   $(".name-main").addClass("error-input");
                   $("<span class='red-text'>Enter your full name</span>").insertAfter("#register-name");
		   flag++;		
		}
		if(email=="")
   		{
                   $(".email-main").addClass("error-input");
                   $("<span class='red-text'>Enter Email Address</span>").insertAfter("#register-email");
		   flag++;		
		}


		var atpos = email.indexOf("@");
    		var dotpos = email.lastIndexOf(".");
		/** email validation **/
    		if ((atpos<1 || dotpos<atpos+2 || dotpos+2>=email.length) && email.length!=0) {
        		
                        $(".email-main").addClass("error-input");
                        $("<span class='red-text'>Enter a valid email address</span>").insertAfter("#register-email");
		   	flag++;	 
    		}
		 
		 
		

	 
		 
		if(flag==0)
		{
			$(".close").click();
			$.ajax({
				url: 'function.php',
				type: 'post',
				dataType:'text',
				data: {function_name:'getEditProfile',name:full_name,email:email,submit:1},
				success: function(text) {
				 if(text==="1")
				 {
					//$("#results").html("<div class='success'>General Info Updated Successfully</div>");
					$("#results").append("<div class='loading1'><img src='images/loading.gif'></div>");
					window.setTimeout(function() {
    					window.location.href = 'profile-step2.php';
					}, 2000);
				 }
				 else
				 { 
				 	$("#results").html(text);
				 }				
				 },
			
			});
		        	
		}
		else
		{
			$("#results").html("");
			//$("#error-text").html(error);	
			//$("#error-modal").click();
			return false;	
		}
				
	});
	
   	$(".back").click(function(){
		window.location.href="index.php";
	});
});
</script>

<!-- error modal -->

<!-- Trigger the modal with a button -->
<button type="button" class="btn btn-info btn-lg hide" id="error-modal" data-toggle="modal" data-target="#myModal">Open Modal</button>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3 class="model-title">Error</h3>
      </div>
      <div class="modal-body">
        <div id="error-text"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<!-- end -->

