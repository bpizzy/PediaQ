<?php require "function.php";CheckLogin(); getHeader();// load main function file and then load header ?>

<?php

	$getAddress   = getDefaultAddress();
	if(isset($getAddress->id))
	{
		$address   = $getAddress->street;
		$apisuite  = $getAddress->apt_suite;
		$mode 	   = "edit";	
		$addressId = $getAddress->id;
		$zip 	   = $getAddress->zip;
		$streetnumber = $getAddress->street_number;
	}
	else
	{
		$address   = "";
		$apisuite  = "";	
		$mode 	   = "add";
		$addressId = "0";
		$zip 	   = "";
		$streetnumber = "";
	}

	if(isset($_POST['submit']))
	{
	  				
		if($return->success)
		{
		      	   $_SESSION['user_token'] =  $return->token;
			   Header( "HTTP/1.1 301 Moved Permanently" ); 
			   Header( "Location: profile-step5.php" ); 
			}
			/** end **/	
	
		 
	}

?>
<div class="container">

 
<div class="row">

<h3 class="form-head">Visit Location<span><b class="steps">Step 4 of 5</b></span></h3>
 
<div class="col-md-3"></div>

<div class="col-md-6">
<div id="result"></div>
<form class="add-patient-form"  method="post">
<div class="form-group address_main">
        <label for="mobile">ADDRESS</label>
        <input type="text" value="<?php echo $address;?>" name="address" onfocus="geolocate()" placeholder="Enter your address" autocomplete="off" id="autocomplete" class="form-control">
      </div>
	  <div class="form-group">
        <label for="mobile">APT/SUITE#</label>
        <input type="text"  value="<?php echo $apisuite;?>" name="aptsuite" placeholder="APT / SUITE#" autocomplete="off" id="aptsuite" class="form-control">
      </div>

 
 <div class="clear"> </div>
  	  <div class="form-group">
       <button type="button" name="submit" id="addLocation"  class="btn btn-info next">Next</button><button type="button" class="btn btn-info back" onclick="window.location.href='profile-step3.php'">Back</button>
      </div>
</form>


 <table id="address"class="hide">
      <tr>
        <td class="label">Street address</td>
        <td class="slimField"><input class="field" id="street_number" value="<?php echo $streetnumber;?>" disabled="true"></input></td>
        <td class="wideField" colspan="2"><input class="field" id="route" disabled="true"></input></td>
      </tr>
      <tr>
        <td class="label">City</td>
        <td class="wideField" colspan="3"><input class="field" id="locality" disabled="true"></input></td>
      </tr>
      <tr>
        <td class="label">State</td>
        <td class="slimField"><input class="field" id="administrative_area_level_1" disabled="true"></input></td>
        <td class="label">Zip code</td>
        <td class="wideField"><input class="field" value="<?php echo $zip;?>" id="postal_code" disabled="true"></input></td>
      </tr>
      <tr>
        <td class="label">Country</td>
        <td class="wideField" colspan="3"><input class="field" id="country" disabled="true"></input></td>
      </tr>
    </table>
<div class="col-md-12"><br> 

</div> 

</div>

<div class="col-md-3"></div>
</div>
</div>
<?php getFooter();?>

<script>
$("document").ready(function(){


setTimeout(function(){
  if ($('.success').length > 0) {
    $('.success').slideToggle();
  }
}, 5000);


   	$("#addLocation").click(function(){
                 $(".warning").remove();$(".address_main").removeClass("error-input");
		 $("#result").html("<div class='loading-center'><img src='images/loading.gif'></div>");
 		 var flag 	= 0;
		 var error      = "";
         	 var location 	= $("#autocomplete").val();
		 var suite	= $("#aptsuite").val();
		 var zip 	= $("#postal_code").val();
		 var snumber	= $("#street_number").val();
			
	 
	
		
		if(location.trim()=="")
		{
		        $(".address_main").addClass("error-input");
                        $("<span class='red-text'>Enter your Address</span>").insertAfter("#autocomplete");
			flag++;		
		}
		
		
		/** if error **/
		if(flag!=0)
		{
			$("#result").html("");
		}
		/** end **/

		/** if no error **/
		if(flag==0)
		{
		 
			
			$.ajax({
				url: 'function.php',
				type: 'post',
				dataType:'text',
				data: {function_name:'addAddress',address: location,snumber:snumber,zip:zip,apt:suite,mode:'<?php echo $mode;?>',address_id:'<?php echo $addressId;?>'},
				success: function(text) 
				{

					if(typeof $(text).find(".warning").html()=="undefined")//success
					{
						$("#result").html('');
						setTimeout(function close(){ window.location.href='profile-step5.php'}, 1000);
					}
					else
					{
						$("#result").html(text);
					}
				},
			
			});

			
		}
		/** end **/

        });

	 
});
</script>



<script src="js/autocompletelocations.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDSQ2Um7BMl7Pb4t-SqnQPO-lE_snXUXi4&libraries=places&callback=initAutocomplete"
        async defer></script>
