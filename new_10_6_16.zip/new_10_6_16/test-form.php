<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<form method="post" action="#">
    
  
    
    <div id="exercises">
        <div class="exercise">
            <div class="form-group">
				<h3 class="form-head"><span><b>Child #1</b></span></h3>
				<label for="fullname">Full name</label>
				<input type="text" placeholder="Enter your child’s first &amp; last name" id="fullname" class="form-control">
			</div>
			<div class="form-group dob-box">
				<label for="DOB">Birth Date</label>
				<div class="clear"></div>
				<div class="db-styled-select styled-select  blue semi-square">
					<select id="month">
						<option value="">MM</option>
						<?php for($i=1;$i<=12;$i++){?>
						<option value="<?php echo $i;?>"><?php echo $i;?></option>
						<?php }?>
					</select>
				</div>
				<span class="devider">/</span>
				<div class="db-styled-select styled-select  blue semi-square">
				  <select id="days">
					<option value="">DD</option>
					 <?php for($i=1;$i<=31;$i++){?>
					 <option value="<?php echo $i;?>"><?php echo $i;?></option>
					<?php }?>
				  </select>
				</div>
				<span class="devider">/</span>
				<div class="db-styled-select styled-select  blue semi-square">
				  <select id="year">
					<option value="">YYYY</option>
					 <?php for($i=1998;$i<=2016;$i++){?>
					 <option value="<?php echo $i;?>"><?php echo $i;?></option>
					<?php }?>
				  </select>
				</div>
				<div class="clear"> </div>
			</div>
			<div class="clear"> </div>
			<div class="form-group">
				<label for="fullname">Gender</label>
				<div class="clear"> </div>
				<div class="styled-select blue semi-square">
					<select id="gender">
						<option value="">Gender</option>
						<option value="male">Male</option>
						<option value="female">Female</option>
					</select>
				</div>
			</div>
			<button class="remove rem deletechildren" style="display:none;">DELETE THIS CHILD</button>
			</div>
			
        
    </div>
	<div class="form-group">
				<button type="button" class="btn btn-info addchildren" id="add_exercise">+ ADD ANOTHER CHILD</button>
			</div>
			<div class="form-group">
				<button type="submit" name="submit"  class="btn btn-info next addchild">Next</button><button type="button" class="btn btn-info back">Cancel</button>
			</div>
            
    
    
</form>
  
  <script>
   $('#add_exercise').on('click', function() {
		$('.rem').show();
    $('#exercises').append(
	'<div class="exercise"> <div class="form-group"><h3 class="form-head"><span><b>Child #1</b></span></h3><label for="fullname">Full name</label><input type="text" placeholder="Enter your child’s first &amp; last name" id="fullname" class="form-control"></div><div class="form-group dob-box"><label for="DOB">Birth Date</label><div class="clear"></div><div class="db-styled-select styled-select  blue semi-square"><select id="month"><option value="">MM</option><?php for($i=1;$i<=12;$i++){?><option value="<?php echo $i;?>"><?php echo $i;?></option><?php }?></select></div><span class="devider">/</span><div class="db-styled-select styled-select  blue semi-square"><select id="days"><option value="">DD</option><?php for($i=1;$i<=31;$i++){?><option value="<?php echo $i;?>"><?php echo $i;?></option><?php }?></select></div><span class="devider">/</span><div class="db-styled-select styled-select  blue semi-square"> <select id="year"><option value="">YYYY</option><?php for($i=1998;$i<=2016;$i++){?><option value="<?php echo $i;?>"><?php echo $i;?></option><?php }?></select></div><div class="clear"> </div></div><div class="clear"> </div><div class="form-group"><label for="fullname">Gender</label><div class="clear"> </div><div class="styled-select blue semi-square"><select id="gender"><option value="">Gender</option><option value="male">Male</option><option value="female">Female</option></select></div></div><button class="remove deletechildren" style="display:none;">DELETE THIS CHILD</button></div>');
    return false; //prevent form submission
});

$('#exercises').on('click', '.remove', function() {
    $(this).parent().remove();
    return false; //prevent form submission
});
</script>
