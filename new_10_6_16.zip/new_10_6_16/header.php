<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Transfer</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="css/custom.css" rel="stylesheet" type="text/css">

<!------ fonts ------------->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
</head>

<body>

<!-- header starts here -->
<header  class="container">
		<div class="row">
			<div class="col-md-12">
				<a href="index.php" class="logo"><img src="logo.png" alt="logo"/></a>
			</div>
		</div>
</header>
