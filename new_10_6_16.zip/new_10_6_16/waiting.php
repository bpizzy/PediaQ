<?php require "function.php";CheckLogin();waitstate();  getHeader();// load main function file and then load header ?>

<?php
	$profile  	= getProfile("all");
        $waitinfo 	= checkwaittime("data");
	$time     	= $waitinfo->result->waitTime/(60);
	$getaddress 	= getAddressbyId($_SESSION['request_address']);
	$nurses   	= getAvailabeleNurse();


 

	/** save card **/
	if(isset($_POST["payment_method_nonce"]))
	{
	  	 
	        $data = array(
			"token" 	=> getUserToken(),
			"paymentNonce"  => $_POST["payment_method_nonce"],
			"isDefault"     => 1
		);
		$url  = "api/payment/add";
		$post = json_decode(PostData($url,$data)); 
	 	if($post->success==1)
		{
			$_SESSION['success'] = "Payment method is Saved";
			$_SESSION['actual_payment_token'] = $post->paymentMethod->paymentToken;
			redirect("profile-step4.php");	
		}
		else
		{
			$_SESSION['error'] = $post->errors->message;
		}
		 
	}
	/** end **/
	$payment = getPaymentCards();
	
?>

<div class="container">

<div id="page-result"></div>
 
<div class="row">

<h3 class="form-head">Waiting for a Pediatric Specialist<span><i>Estimated wait time/ <?php echo $time;?> min</i></span></h3>
 <br>
<form method="post">
<div class="col-md-7">
<div class="col-md-2">
<img src="images/pediaq.png" class="pull-right"/>
</div>
<div class="col-md-9">
<p>We are sorry, all our Pediatric Specialists are currently busy helping other Patient</p><br>
<p>You will recieve a call as soon as one of our Pediatric Specialists becomes Available</p><br>
<p>Thank you for your patience.</p><br>
<p class="request-red-text">For medical emergencies, Please dial 911</p>

</div>

</div>


 

<div class="col-md-4 border">

<div id="map" style="width:100%; height: 250px;"></div>

<br><br>
<div class="col-md-12">
	<b>Visit Location </b><br><br>
	<p class="visitss"><?php echo $getaddress->street; ?></p>
</div>

<div class="col-md-12">
	<b>Payment Method <a class="pull-right pointer" id="change-payment-trigger">Change</a></b> <br><br>
	<?php if(count($payment)){ foreach($payment as $card){ if($card->isDefault=="1"){?>
	<p><?php echo $card->paymentMethodInfo->paymentTypeName." ...".$card->paymentMethodInfo->last4;?></p>
	<?php }}}?>
<!-- end payments -->

</div>

 <button type="button" name="submit" data-toggle="modal" data-target="#contact_us_modal" class="btn btn-info next_blank_contact pull-left">Got Questions? Contact us!</button>

<p class="text-center pointer" id="wait-loading-cancel" style="clear:both">Cancel Request</p>


</div>
</div>
</div>
</form>
<br><br><br>
<?php getFooter();?>

<!-- error modal -->

<!-- Trigger the modal with a button -->
<button type="button" class="btn btn-info btn-lg hide" id="error-modal" data-toggle="modal" data-target="#myModal">Open Modal</button>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3 class="model-title">Error!</h3>
      </div>
      <div class="modal-body">
        <div id="error-text"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<!-- end -->


<script src="https://js.braintreegateway.com/js/braintree-2.22.2.min.js"></script>
<script>
// We generated a client token for you so you can test out this code
// immediately. In a production-ready integration, you will need to
// generate a client token on your server (see section below).
var clientToken = "<?php echo getPaymentToken();?>";

braintree.setup(clientToken, "dropin", {
  container: "payment-form"
});
</script>


<!-- delete cancel request -->

<!-- Trigger the modal with a button -->
<button type="button" id="delete-request-buttons" class="btn btn-info btn-lg hide" data-toggle="modal" data-target="#deleteRequest">Open Modal</button>

<!-- Modal -->
<div id="deleteRequest" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="model-title">Cancel Request</h4>
      </div>
      <div class="modal-body">
        <div id="delete-request-result"></div>
        <p>Are you sure you want to cancel this Request?</p>
      </div>
      <div class="modal-footer">
        	<button type="button" name="submit"  id="delete-request-submit" class="btn btn-info next2 cancel_request_modal_button">Cancel Request</button><button data-dismiss="modal" type="button" class="btn btn-info back">Never Mind</button>
      </div>
    </div>

  </div>
</div>
<!-- end -->




<!-- change payment -->

<!-- Trigger the modal with a button -->
<button type="button" id="change-payment-button" class="btn btn-info btn-lg hide" data-toggle="modal" data-target="#change-payment">Open Modal</button>

<!-- Modal -->
<div id="change-payment" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header no-border">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="text-center model-title" style="text-align:center;">Add Payment Method</h4>
      </div>
      <div class="modal-body">
      
       <form class="add-patient-form"   id="checkout" method="post">
  <div id="payment-form"></div>
      	   
      </div>
      <div class="modal-footer">
        	<button type="submit" name="submit"  class="btn btn-info next">Save</button> 
      </div>
    </div>
</form>
  </div>
</div>
<!-- end -->




<!-- contact us -->

 
<!-- Modal -->
<div id="contact_us_modal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="text-center model-title">Contact Us</h4>
      </div>
      <div class="modal-body">
	<br><br>
        <div class="col-md-12 fee"><b>Call</b> <a class="pull-right  fee-cost">(214) 984-3900</a></div>
	<div class="col-md-12 fee"><b>Email</b> <a class="pull-right  fee-cost" href="mailto:support@pediaq.care">support@PediaQ.care</a></div><br><br>
        <span class="request-red-text">For medical emergencies, Please dial 911</span>
      </div>
      <div class="modal-footer">
        	<button type="button" class="btn btn-default white-color" data-dismiss="modal">Close</button>
      </div>
    </div>
 
  </div>
</div>
<!-- end -->


<!-- select location -->
<!-- Trigger the modal with a button -->
<button type="button" id="openlocationform" class="btn btn-info btn-lg hide" data-toggle="modal" data-target="#addlocationform">Open Modal</button>

<!-- Modal -->
<div id="addlocationform" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3 class="model-title">Select Visit Location</h3>
      </div>
      <div class="modal-body">
         <label>Address</label>
	  <div class="select-address-body"></div>
		<a class="pointer" data-toggle="modal"  data-dismiss="modal" data-target="#addlocation">+ ADD ANOTHER ADDRESS</a>
      </div>
 <div class="modal-footer">
           
      </div>

      </div>

  </div>
</div>
<!-- end -->


<!-- add location -->
<!-- Modal -->
<div id="addlocation" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3 class="model-title">Add Address</h3>
      </div>
      <div class="modal-body">
  <div  id="add-address-result"></div>
   <form class="add-patient-form add-child-form" method="post">
<div class="form-group" id="locationField">
        <label for="mobile">ADDRESS</label>
        <input id="autocomplete" placeholder="Enter your address" onFocus="geolocate()" type="text" class="form-control">
      </div>
	  <div class="form-group">
        <label for="mobile">APT/SUITE#</label>
        <input type="text" name="aptsuite" placeholder="Enter APT/SUITE#" autocomplete="off" id="aptsuite" class="form-control">
      </div>

 
 <div class="clear"> </div>
  	
</form>
    <table id="address"class="hide">
      <tr>
        <td class="label">Street address</td>
        <td class="slimField"><input class="field" id="street_number" disabled="true"></input></td>
        <td class="wideField" colspan="2"><input class="field" id="route" disabled="true"></input></td>
      </tr>
      <tr>
        <td class="label">City</td>
        <td class="wideField" colspan="3"><input class="field" id="locality" disabled="true"></input></td>
      </tr>
      <tr>
        <td class="label">State</td>
        <td class="slimField"><input class="field" id="administrative_area_level_1" disabled="true"></input></td>
        <td class="label">Zip code</td>
        <td class="wideField"><input class="field" id="postal_code" disabled="true"></input></td>
      </tr>
      <tr>
        <td class="label">Country</td>
        <td class="wideField" colspan="3"><input class="field" id="country" disabled="true"></input></td>
      </tr>
    </table>
 </div>
 <div class="modal-footer">
            <button type="button" name="submit"  id="addaddress-submit" class="btn btn-info next1">Save</button><button data-dismiss="modal" id="list-address" type="button" class="btn btn-info back">Back</button>
	
      </div>

      </div>

  </div>
</div>
<!-- end -->




<!-- delete address modal -->
<button type="button" class="btn btn-info btn-lg hide" id="delete-address-button" data-toggle="modal" data-target="#deleteaddress">Open Modal</button>
<!-- Modal -->
<div id="deleteaddress" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3 class="model-title">Delete Visit Location</h3>
      </div>
      <div class="modal-body">
<div id="deleteaddress-result"></div>
        <p>Are you sure you want to delete this address?</p>
      </div>
      <div class="modal-footer">
      <button type="button" name="submit"  id="delete-address-submit" class="btn btn-info next2">Delete</button><button data-dismiss="modal" type="button" class="btn btn-info back">Cancel</button>
      </div>
    </div>

  </div>
</div>

<!-- end -->



<!-- modal for edit address -->
<!-- Trigger the edit address modal with a button -->
<button type="button" class="btn btn-info btn-lg hide" id="editLocationform-button" data-toggle="modal" data-target="#editLocationform">Open Modal</button>

<!-- Modal -->
<div id="editLocationform" class="modal fade" role="dialog">
  <div class="modal-dialog">

<!-- Modal content-->
<div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3 class="model-title">Edit Address</h3>
      </div>
      <div class="modal-body edit-address-form">
      <div id="edit-address-result"></div>
      <form class="add-patient-form add-child-form" method="post">
		<div class="form-group" id="locationField">
			<label for="mobile">ADDRESS</label>
			<input id="autocomplete3" placeholder="Enter your address" onfocus="geolocate()" type="text" class="form-control" autocomplete="off">
	       </div>
	       <div class="form-group">
		<label for="mobile">APT/SUITE#</label>
		<input type="hidden" id="edit_address_id" />
		<input type="text" name="aptsuite" placeholder="Enter APT/SUITE#" autocomplete="off" id="aptsuite" class="form-control aptsuite">
	      </div>
	<div class="clear"> </div>
	</form>
	<table id="address"class="hide">
	      <tr>
		<td class="label">Street address</td>
		<td class="slimField"><input class="field street_number"></input></td>
		<td class="wideField" colspan="2"><input class="field route"></input></td>
	      </tr>
	      <tr>
		<td class="label">City</td>
		<td class="wideField" colspan="3"><input class="field locality"></input></td>
	      </tr>
	      <tr>
		<td class="label">State</td>
		<td class="slimField"><input class="field administrative_area_level_1"></input></td>
		<td class="label">Zip code</td>
		<td class="wideField"><input class="field postal_code"></input></td>
	      </tr>
	      <tr>
		<td class="label">Country</td>
		<td class="wideField" colspan="3"><input class="field country"></input></td>
	      </tr>
	</table>
</div>
<div class="modal-footer">
           <button type="button" name="submit" id="update-location-submit" class="btn btn-info next1">Save</button>
	   <button data-dismiss="modal" type="button" class="btn btn-info back" onclick='$(".addlocationform").click();'>Cancel</button>
      </div>
</div>

  </div>
</div>
<!-- end -->



<!-- Trigger the modal with a button -->
<button type="button" class="btn btn-info btn-lg hide" id="workinghourend-trigger" data-toggle="modal" data-target="#workinghourend">Open Modal</button>

<!-- working hour end Modal -->
<div id="workinghourend" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="model-title">Request Cancelled</h4>
      </div>
      <div class="modal-body">
        <p>We are sorry, PediaQ has closed for the day, and your visit request has been cancelled.</p><br><br>
	<i>For medical emergencies, please dial 911 </i>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" onclick="window.location.href='cancel_request.php'">ok</button>
      </div>
    </div>

  </div>
</div>
<!-- end -->


<!-- Trigger the modal with a button -->
<button type="button" class="btn btn-info btn-lg hide" id="admin-error-trigger" data-toggle="modal" data-target="#adminerror">Open Modal</button>

<!-- working hour end Modal -->
<div id="adminerror" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="model-title">Request Cancelled</h4>
      </div>
      <div class="modal-body">
        <p>We are sorry, your request has been cancelled by admin.</p><br><br>
	<i>For medical emergencies, please dial 911 </i>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" onclick="window.location.href='cancel_request.php'">ok</button>
      </div>
    </div>

  </div>
</div>
<!-- end -->

<script>
$(document).ready(function(){

/** delete Request **/
$("#wait-loading-cancel").click(function(){
	$(".close").click();
	$("#delete-request-buttons").click();
});
/** end **/


/** delete Request redirect **/
$("#delete-request-submit").click(function(){

	$("#delete-request-result").html("<div class='loading1'><img src='images/loading.gif'></div>");
	
	$.ajax({
					url: 'function.php',
					type: 'POST',
					dataType: 'text',
					data:{function_name:'CancelRequest',status:"1"},
					success : function(text)
					{
						if(typeof $(text).find(".success").html()!=="undefined")
						{
							  window.setTimeout(function() {
    					       			window.location.href = 'cancel_request.php';
					      		  }, 2000);
						}
						else
						{
							$("#delete-request-result").html(text);												
						}
					},
	});	


});
/** end **/


/** change payment Request **/
$("#change-payment-trigger").click(function(){
	$(".close").click();
	$("#change-payment-button").click();
});
/** end **/



/** open location **/
$(".addlocationform,#list-address").click(function(){
	$("#openlocationform").click();
	$(".select-address-body").html("<div class='loading1'><img src='images/loading.gif'></div>");
	$.ajax({
				url: 'function.php',
				type: 'post',
				dataType:'text',
				data: {function_name:'getAddressesajax',status:1},
				success: function(text) {
				$(".select-address-body").html(text);
				},
			
			});
});

/** end **/




/** add address submit **/ 
$("#addaddress-submit").click(function(){  
	$("#add-address-result").html('');
$("#add-address-result").append("<div class='loading1'><img src='images/loading.gif'></div>");
	var address		= $("#autocomplete").val();  
	var street_number 	= $("#street_number").val();
	var city		= $("#locality").val();  
	var state	 	= $("#administrative_area_level_1").val(); 
	var post_code	 	= $("#postal_code").val(); 
	var country             = $("#country").val();
	var apt 		= $("#aptsuite").val();

	if(post_code=="")
	{
		post_code = "00000";	
	}
	
	if(address!="")
	{
	$.ajax({
		url: 'function.php',
		type: 'post',
		dataType:'text',
		data:{function_name:'addAddress',address:address,snumber:street_number,city:city,country:country,zip:post_code,apt:apt,state:state,default:0},
		success: function(text) {

			if(typeof $(text).find(".warning").html()==="undefined")
			{
			/** call another ajax to see default address existence **/ 

				$.ajax({
				url: 'function.php',
				type: 'post',
				dataType:'text',
				data: {function_name:'getDefaultAddressAjax',status:1},
				success: function(result) {
					if(result!="")
					{
						$(".visits").html(result);
						$(".close").click();
						$(".addlocationform").click();
						$("#add-address-result").html('');
					}
					else
					{
						$("#add-address-result").html(text);	
					}
					
				},
			
			});

			/** end **/
			}
			else
			{
					$("#add-address-result").html(text);
			}
		
		},
	});
  	}
	else
	{
		$("#add-address-result").html("<div class='warning'>Please Specify Address</div>");
	}
}); 
/** end **/ 



/** add default address **/
$(document).on("click",".ajax-address",function(e){

	var address_id = $(this).attr("id");
	var html = $(this).text();
	if(address_id)
	{
		$.ajax({
			url: 'function.php',
			type: 'post',
			dataType:'text',
			data:{function_name:'updatedefaultaddress',address_id:address_id},
			success: function(text) {
				$(".visitss").html(html);
				$(".close").click();
				 			
			},
		});				
	}

});	
/** end **/ 

/** delete address **/
$(document).on("click",".delete-address",function(e){ 
	var id = $(this).attr("address_id");
        $("#deleteaddress-result").html("");
	$("#delete-address-button").click();
	$("#delete-address-submit").attr('address_id',id);

});

$("#delete-address-submit").click(function(){

$("#deleteaddress-result").append("<div class='loading1'><img src='images/loading.gif'></div>");
	var id = $(this).attr("address_id");
	if(id!="")
	{
		$.ajax({
			url: 'function.php',
			type: 'post',
			dataType:'text',
			data:{function_name:'deleteAddress',address_id:id},
			success: function(text) {
				if($(text).find(".warning").html()!=="undefined")
				{
					$(".visits").prepend(text);
					$(".close").click();
				}
				else
				{
					$("#"+id).remove();
					$(".visits").html(text);
					$(".close").click();
				}
			},
		});

	}

});

/** end **/
	 

/** edit location **/
$(document).on("click",".edit-address",function(e){ 
	$("#editLocationform-button").click();
	var id = $(this).attr('address_id');
	$.ajax({
			url: 'function.php',
			type: 'POST',
			dataType: 'text',
			data:{function_name:'getEditAddressForm',address_id:id},
			success : function(text)
			{
				$('#autocomplete3').val($(text).find(".street").html());
				$('.postal_code').val($(text).find(".zip").html());
				$('.aptsuite').val($(text).find(".apt_suite").html());
				$('.street_number').val($(text).find(".street_number").html());
				$('#edit_address_id').val($(text).find(".address_id").html());
			},
		});
});
/** end **/


/** update location **/
$("#update-location-submit").click(function(){
	 
     $("#edit-address-result").append("<div class='loading1'><img src='images/loading.gif'></div>");
	var street_number = $(".street_number").val();
	var aptsuite      = $(".aptsuite").val();
	var street        = $("#autocomplete3").val();
	var id            = $("#edit_address_id").val();
	var zip           = $(".postal_code").val();

	
	if(zip=="")
	{
		zip = "00000";
	}

	if(street=="")
	{
		 $("#edit-address-result").html("<div class='warning'>Please fill the address</div>");
	}
	else
	{
		/** edit address ajax **/
		$.ajax({
			url: 'function.php',
			type: 'POST',
			dataType: 'text',
			data:{function_name:'getEditAddress',id:id,zip:zip,street:street,apt_suite:aptsuite,street_number:street_number},
			success : function(text)
			{
				if($(text).find(".success").html()!=="undefined")
				{
					$("#edit-address-result").append(text);
					
					setTimeout(function close(){$(".close").click(); $(".addlocationform").click();$("#edit-address-result").html('');}, 1000);
				
				}
				else
				{
					$("#edit-address-result").html(text);
				}			
			},
		});
		/** end **/
	}
});
/** end **/

/** add promocode modal **/
$("#add-promo").click(function(){
	$("#add-promo-result").html("");
	$("#add-promocode").click();
});
/** end **/


});

/** check availability **/
setInterval( function update() {
     	$("#page-result").html("<div class='loading-center'><img src='images/loading.gif'></div>");
	$.ajax({
			url: 'function.php',
			type: 'POST',
			dataType: 'text',
			data:{function_name:'acceptrequest',status:1},
			success : function(text)
			{
			  
				if(typeof $(text).find(".success").html()==="undefined")
				{
					if(typeof $(text).find(".operation-error").html()!=="undefined")
					{
						$("#workinghourend-trigger").click();	
						$("#page-result").html(text);		
					}
					 					
					if(typeof $(text).find(".admin-error").html()!=="undefined")
					{
						$("#admin-error-trigger").click();
						$("#page-result").html(text);			
					}

 						
					 				
				}
				if(text==="1")
				{
					window.location.href='accept_request.php';
				}			
			},
		});
} , 40000 );
/** end **/

</script>


 <script type="text/javascript" src="//maps.google.com/maps/api/js?sensor=false"></script>
    <script type='text/javascript'>//<![CDATA[
	window.onload=function(){
	
	var locations = [
	    ['<?php echo $getaddress->street;?>',<?php echo $getaddress->latitude;?>, <?php echo $getaddress->longitude;?>, 1, "images/circle.png"],
	    ['Pediatric Specialist',<?php echo $getNurseLocation->location->latitude;?>, <?php echo $getNurseLocation->location->longitude;?>, 2, "images/loc-icon.png"]
	];
	
	
	 


	var map = new google.maps.Map(document.getElementById('map'), {
	    zoom: 16,
	    center: new google.maps.LatLng(<?php echo $getaddress->latitude;?>, <?php echo $getaddress->longitude;?>),
	    mapTypeId: google.maps.MapTypeId.ROADMAP
	});

	var infowindow = new google.maps.InfoWindow();

	var marker, i;

	for (i = 0; i < locations.length; i++) {
	    marker = new google.maps.Marker({
		position: new google.maps.LatLng(locations[i][1], locations[i][2]),
		icon: locations[i][4],
		map: map
	    });

	    google.maps.event.addListener(marker, 'click', (function (marker, i) {
		return function () {
		    infowindow.setContent(locations[i][0]);
		    infowindow.open(map, marker);
		}
	    })(marker, i));
	}
	}//]]> 

</script>

  

