<?php require "function.php";CheckLogin();   getHeader();// load main function file and then load header ?>

<?php
	
	$current = getCurrentRequestStatus();
	/** check if not accepted **/
	if($current->success=="1" and $current->request->nurseId=="")
	{	
		redirect("waiting.php");	
	}
	/** end **/ 	
	$_SESSION['request_nurse_id'] = $current->request->nurseId;
	$profile  		= getProfile("all");
	$getaddress 		= getAddressbyId($_SESSION['request_address']);
	$nurseProfile 		= getNurseProfile($_SESSION['request_nurse_id']);
	$nurses  		= getAvailabeleNurse();
	$getNurseLocation 	= getNurseLocation($nurseProfile->nurse->id);
	if($nurseProfile->success=="1")
	{
		$image      	= $nurseProfile->nurse->image;
		$name       	= $nurseProfile->nurse->name;
		$average_rating = ($nurseProfile->nurse->averageRating/10);
		$reviews 	= count($nurseProfile->nurse->comments);
		$comments 	= $nurseProfile->nurse->comments;
		$specialist	= $nurseProfile->nurse->specialization;
		$language       = "English";
		$education      = $nurseProfile->nurse->education;
		if($nurseProfile->nurse->resume!="")
		{
			$bio 		= $nurseProfile->nurse->resume; 
		}
		else
		{
			$bio 		= "No Information Specified";	
		}
	}
	else
	{
		$image = "images/nurse_dummy.png";
	}

 

	/** save card **/
	if(isset($_POST["payment_method_nonce"]))
	{
	  	 
	        $data = array(
			"token" 	=> getUserToken(),
			"paymentNonce"  => $_POST["payment_method_nonce"],
			"isDefault"     => 1
		);
		$url  = "api/payment/add";
		$post = json_decode(PostData($url,$data)); 
	 	if($post->success==1)
		{
			$_SESSION['success'] = "Payment method is Saved";
			$_SESSION['actual_payment_token'] = $post->paymentMethod->paymentToken;
			redirect("profile-step4.php");	
		}
		else
		{
			$_SESSION['error'] = $post->errors->message;
		}
		 
	}
	/** end **/
	$payment = getPaymentCards();
	
?>

<div class="container">

<div id="page-result"></div>
 
<div class="row">

<h3 class="form-head">Request Accepted<span> <i> You will receive a call from your Pediatric Specialist in  10 minutes </i></span></h3>
 <br>
<form method="post">
<div class="col-md-7">
<div class="col-md-2">
<img src="<?php echo $image;?>" class="pull-right nurse_image"/>
</div>
<div class="col-md-9">
<p><b><?php echo $name;?></b><br><span id="review-tab" data-toggle="modal" data-target="#reviews-modal" class="pointer"><img height="20px" src="images/stars.png"/><span class="blue-text"> <?php echo $average_rating." / ".$reviews;?> Reviews</span> </span></p>
<p><br></p>
<p class="text-uppercase">Specialist</p>
<p><?php echo $specialist;?></p>


<p><br></p>
<p class="text-uppercase">Bio</p>
<p class="bio"><?php echo $bio;?></p>
<?php if(strlen($bio)>200){?>
<a class="read-more-button pointer" id="bio" data-toggle="modal" data-target="#resumetrigger">Read More</a>
<?php }?>
 
<p><br></p>
<p class="text-uppercase">Education</p>
<?php if(count($education)){?>
<p class="education"><?php echo $education[0]->university;?>, <?php echo $education[0]->degree;?> <?php echo $education[0]->year;?> </p>
<?php }else{
echo '<p class="education">No Information Specified</p>';
}?>
 
<?php if(count($education)>1){?>
<a class="read-more-button pointer" id="education" data-toggle="modal" data-target="#educationtrigger">Read More</a>
<?php }?>


<p><br></p>
<p class="text-uppercase">Language</p>
<p class="language"> <?php echo $language;?> </p>

 

</div>

</div>


 

<div class="col-md-4 border">

<div id="map" style="width:100%; height: 250px;"></div>


<br><br>
<div class="col-md-12">
	<b>Visit Location <a class="pull-right pointer addlocationform" id="change-location">Change</a></b><br><br>
	<p class="visitss"><?php echo $getaddress->street; ?></p>
</div>

<div class="col-md-12">
	<b>Payment Method <a class="pull-right pointer" id="change-payment-trigger">Change</a></b> <br><br>
	<?php if(count($payment)){ foreach($payment as $card){ if($card->isDefault=="1"){?>
	<p><?php echo $card->paymentMethodInfo->paymentTypeName." ...".$card->paymentMethodInfo->last4;?></p>
	<?php }}}?>
<!-- end payments -->

</div>

 <button type="button" name="submit" data-toggle="modal" data-target="#contact_us_modal" class="btn btn-info next_blank_contact pull-left">Got Questions? Contact us!</button>

<p class="text-center pointer" id="wait-loading-cancel" style="clear:both">Cancel Request</p>


</div>
</div>
</div>
</form>
<br><br><br>
<?php getFooter();?>

<!-- error modal -->

<!-- Trigger the modal with a button -->
<button type="button" class="btn btn-info btn-lg hide" id="error-modal" data-toggle="modal" data-target="#myModal">Open Modal</button>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3 class="model-title">Error!</h3>
      </div>
      <div class="modal-body">
        <div id="error-text"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<!-- end -->


<script src="https://js.braintreegateway.com/js/braintree-2.22.2.min.js"></script>
<script>
// We generated a client token for you so you can test out this code
// immediately. In a production-ready integration, you will need to
// generate a client token on your server (see section below).
var clientToken = "<?php echo getPaymentToken();?>";

braintree.setup(clientToken, "dropin", {
  container: "payment-form"
});
</script>


<!-- delete cancel request -->

<!-- Trigger the modal with a button -->
<button type="button" id="delete-request-buttons" class="btn btn-info btn-lg hide" data-toggle="modal" data-target="#deleteRequest">Open Modal</button>

<!-- Modal -->
<div id="deleteRequest" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="model-title">Cancel Request</h4>
      </div>
      <div class="modal-body">
        <div id="delete-request-result"></div>
        <p>Are you sure you want to delete this Request?</p>
      </div>
      <div class="modal-footer">
        	<button type="button" name="submit"  id="delete-request-submit" class="btn btn-info next2">Cancel Request</button><button data-dismiss="modal" type="button" class="btn btn-info back">Never Mind</button>
      </div>
    </div>

  </div>
</div>
<!-- end -->




<!-- change payment -->

<!-- Trigger the modal with a button -->
<button type="button" id="change-payment-button" class="btn btn-info btn-lg hide" data-toggle="modal" data-target="#change-payment">Open Modal</button>

<!-- Modal -->
<div id="change-payment" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header no-border">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="text-center model-title" style="text-align:center;">Add Payment Method</h4>
      </div>
      <div class="modal-body">
      
       <form class="add-patient-form"   id="checkout" method="post">
  <div id="payment-form"></div>
      	   
      </div>
      <div class="modal-footer">
        	<button type="submit" name="submit"  class="btn btn-info next">Save</button> 
      </div>
    </div>
</form>
  </div>
</div>
<!-- end -->




<!-- contact us -->

 
<!-- Modal -->
<div id="contact_us_modal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="text-center model-title">Contact Us</h4>
      </div>
      <div class="modal-body">
	<br><br>
        <div class="col-md-12 fee"><b>Call</b> <a class="pull-right  fee-cost">(214) 984-3900</a></div>
	<div class="col-md-12 fee"><b>Email</b> <a class="pull-right fee-cost" href="mailto:support@pediaq.co">support@PediaQ.co</a></div><br><br>
        <span class="request-red-text">For medical emergencies, Please dial 911</span>
      </div>
      <div class="modal-footer">
        	<button type="button" class="btn btn-default white-color" data-dismiss="modal">Close</button>
      </div>
    </div>
 
  </div>
</div>
<!-- end -->


<!-- select location -->
<!-- Trigger the modal with a button -->
<button type="button" id="openlocationform" class="btn btn-info btn-lg hide" data-toggle="modal" data-target="#addlocationform">Open Modal</button>

<!-- Modal -->
<div id="addlocationform" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3 class="model-title">Select Visit Location</h3>
      </div>
      <div class="modal-body">
         <label>Address</label>
	  <div class="select-address-body"></div>
		<a class="pointer" data-toggle="modal"  data-dismiss="modal" data-target="#addlocation">+ ADD ANOTHER ADDRESS</a>
      </div>
 <div class="modal-footer">
           
      </div>

      </div>

  </div>
</div>
<!-- end -->


<!-- add location -->
<!-- Modal -->
<div id="addlocation" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3 class="model-title">Add Address</h3>
      </div>
      <div class="modal-body">
  <div  id="add-address-result"></div>
   <form class="add-patient-form add-child-form" method="post">
<div class="form-group" id="locationField">
        <label for="mobile">ADDRESS</label>
        <input id="autocomplete" placeholder="Enter your address" onFocus="geolocate()" type="text" class="form-control">
      </div>
	  <div class="form-group">
        <label for="mobile">APT/SUITE#</label>
        <input type="text" name="aptsuite" placeholder="Enter APT/SUITE#" autocomplete="off" id="aptsuite" class="form-control">
      </div>

 
 <div class="clear"> </div>
  	
</form>
    <table id="address"class="hide">
      <tr>
        <td class="label">Street address</td>
        <td class="slimField"><input class="field" id="street_number" disabled="true"></input></td>
        <td class="wideField" colspan="2"><input class="field" id="route" disabled="true"></input></td>
      </tr>
      <tr>
        <td class="label">City</td>
        <td class="wideField" colspan="3"><input class="field" id="locality" disabled="true"></input></td>
      </tr>
      <tr>
        <td class="label">State</td>
        <td class="slimField"><input class="field" id="administrative_area_level_1" disabled="true"></input></td>
        <td class="label">Zip code</td>
        <td class="wideField"><input class="field" id="postal_code" disabled="true"></input></td>
      </tr>
      <tr>
        <td class="label">Country</td>
        <td class="wideField" colspan="3"><input class="field" id="country" disabled="true"></input></td>
      </tr>
    </table>
 </div>
 <div class="modal-footer">
            <button type="button" name="submit"  id="addaddress-submit" class="btn btn-info next1">Save</button><button data-dismiss="modal" id="list-address" type="button" class="btn btn-info back">Back</button>
	
      </div>

      </div>

  </div>
</div>
<!-- end -->




<!-- delete address modal -->
<button type="button" class="btn btn-info btn-lg hide" id="delete-address-button" data-toggle="modal" data-target="#deleteaddress">Open Modal</button>
<!-- Modal -->
<div id="deleteaddress" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3 class="model-title">Delete Visit Location</h3>
      </div>
      <div class="modal-body">
<div id="deleteaddress-result"></div>
        <p>Are you sure you want to delete this address?</p>
      </div>
      <div class="modal-footer">
      <button type="button" name="submit"  id="delete-address-submit" class="btn btn-info next2">Delete</button><button data-dismiss="modal" type="button" class="btn btn-info back">Cancel</button>
      </div>
    </div>

  </div>
</div>

<!-- end -->



<!-- modal for edit address -->
<!-- Trigger the edit address modal with a button -->
<button type="button" class="btn btn-info btn-lg hide" id="editLocationform-button" data-toggle="modal" data-target="#editLocationform">Open Modal</button>

<!-- Modal -->
<div id="editLocationform" class="modal fade" role="dialog">
  <div class="modal-dialog">

<!-- Modal content-->
<div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h3 class="model-title">Edit Address</h3>
      </div>
      <div class="modal-body edit-address-form">
      <div id="edit-address-result"></div>
      <form class="add-patient-form add-child-form" method="post">
		<div class="form-group" id="locationField">
			<label for="mobile">ADDRESS</label>
			<input id="autocomplete3" placeholder="Enter your address" onfocus="geolocate()" type="text" class="form-control" autocomplete="off">
	       </div>
	       <div class="form-group">
		<label for="mobile">APT/SUITE#</label>
		<input type="hidden" id="edit_address_id" />
		<input type="text" name="aptsuite" placeholder="Enter APT/SUITE#" autocomplete="off" id="aptsuite" class="form-control aptsuite">
	      </div>
	<div class="clear"> </div>
	</form>
	<table id="address"class="hide">
	      <tr>
		<td class="label">Street address</td>
		<td class="slimField"><input class="field street_number"></input></td>
		<td class="wideField" colspan="2"><input class="field route"></input></td>
	      </tr>
	      <tr>
		<td class="label">City</td>
		<td class="wideField" colspan="3"><input class="field locality"></input></td>
	      </tr>
	      <tr>
		<td class="label">State</td>
		<td class="slimField"><input class="field administrative_area_level_1"></input></td>
		<td class="label">Zip code</td>
		<td class="wideField"><input class="field postal_code"></input></td>
	      </tr>
	      <tr>
		<td class="label">Country</td>
		<td class="wideField" colspan="3"><input class="field country"></input></td>
	      </tr>
	</table>
</div>
<div class="modal-footer">
           <button type="button" name="submit" id="update-location-submit" class="btn btn-info next1">Save</button>
	   <button data-dismiss="modal" type="button" class="btn btn-info back" onclick='$(".addlocationform").click();'>Cancel</button>
      </div>
</div>

  </div>
</div>
<!-- end -->



<!-- Trigger the modal with a button -->
<button type="button" class="btn btn-info btn-lg hide" id="workinghourend-trigger" data-toggle="modal" data-target="#workinghourend">Open Modal</button>

<!-- working hour end Modal -->
<div id="workinghourend" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="model-title">Request Cancelled</h4>
      </div>
      <div class="modal-body">
        <p>We are sorry, PediaQ has closed for the day, and your visit request has been cancelled.</p><br><br>
	<i>For medical emergencies, please dial 911 </i>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" onclick="window.location.href='dashboard.php'">ok</button>
      </div>
    </div>

  </div>
</div>
<!-- end -->

<script>
$(document).ready(function(){

/** delete Request **/
$("#wait-loading-cancel").click(function(){
	$(".close").click();
	$("#delete-request-buttons").click();
});
/** end **/



/** delete Request redirect **/
$("#delete-request-submit").click(function(){

	$("#delete-request-result").html("<div class='loading1'><img src='images/loading.gif'></div>");
	
	$.ajax({
					url: 'function.php',
					type: 'POST',
					dataType: 'text',
					data:{function_name:'CancelRequest',status:"1"},
					success : function(text)
					{
						if(typeof $(text).find(".success").html()!=="undefined")
						{
							  window.setTimeout(function() {
    					       			window.location.href = 'cancel_request.php';
					      		  }, 2000);
						}
						else
						{
							$("#delete-request-result").html(text);												
						}
					},
	});	


});
/** end **/


/** change payment Request **/
$("#change-payment-trigger").click(function(){
	$(".close").click();
	$("#change-payment-button").click();
});
/** end **/



/** open location **/
$(".addlocationform,#list-address").click(function(){
	$("#openlocationform").click();
	$(".select-address-body").html("<div class='loading1'><img src='images/loading.gif'></div>");
	$.ajax({
				url: 'function.php',
				type: 'post',
				dataType:'text',
				data: {function_name:'getAddressesajax',status:1},
				success: function(text) {
				$(".select-address-body").html(text);
				},
			
			});
});

/** end **/




/** add address submit **/ 
$("#addaddress-submit").click(function(){  
	$("#add-address-result").html('');
$("#add-address-result").append("<div class='loading1'><img src='images/loading.gif'></div>");
	var address		= $("#autocomplete").val();  
	var street_number 	= $("#street_number").val();
	var city		= $("#locality").val();  
	var state	 	= $("#administrative_area_level_1").val(); 
	var post_code	 	= $("#postal_code").val(); 
	var country             = $("#country").val();
	var apt 		= $("#aptsuite").val();

	if(post_code=="")
	{
		post_code = "00000";	
	}
	
	if(address!="")
	{
	$.ajax({
		url: 'function.php',
		type: 'post',
		dataType:'text',
		data:{function_name:'addAddress',address:address,snumber:street_number,city:city,country:country,zip:post_code,apt:apt,state:state,default:0},
		success: function(text) {

			if(typeof $(text).find(".warning").html()==="undefined")
			{
			/** call another ajax to see default address existence **/ 

				$.ajax({
				url: 'function.php',
				type: 'post',
				dataType:'text',
				data: {function_name:'getDefaultAddressAjax',status:1},
				success: function(result) {
					if(result!="")
					{
						$(".visits").html(result);
						$(".close").click();
						$(".addlocationform").click();
						$("#add-address-result").html('');
					}
					else
					{
						$("#add-address-result").html(text);	
					}
					
				},
			
			});

			/** end **/
			}
			else
			{
					$("#add-address-result").html(text);
			}
		
		},
	});
  	}
	else
	{
		$("#add-address-result").html("<div class='warning'>Please Specify Address</div>");
	}
}); 
/** end **/ 



/** add default address **/
$(document).on("click",".ajax-address",function(e){

	var address_id = $(this).attr("id");
	var html = $(this).text();
	if(address_id)
	{
		$.ajax({
			url: 'function.php',
			type: 'post',
			dataType:'text',
			data:{function_name:'updatedefaultaddress',address_id:address_id},
			success: function(text) {
				$(".visitss").html(html);
				$(".close").click();
				 			
			},
		});				
	}

});	
/** end **/ 

/** delete address **/
$(document).on("click",".delete-address",function(e){ 
	var id = $(this).attr("address_id");
        $("#deleteaddress-result").html("");
	$("#delete-address-button").click();
	$("#delete-address-submit").attr('address_id',id);

});

$("#delete-address-submit").click(function(){

$("#deleteaddress-result").append("<div class='loading1'><img src='images/loading.gif'></div>");
	var id = $(this).attr("address_id");
	if(id!="")
	{
		$.ajax({
			url: 'function.php',
			type: 'post',
			dataType:'text',
			data:{function_name:'deleteAddress',address_id:id},
			success: function(text) {
				if($(text).find(".warning").html()!=="undefined")
				{
					$(".visits").prepend(text);
					$(".close").click();
				}
				else
				{
					$("#"+id).remove();
					$(".visits").html(text);
					$(".close").click();
				}
			},
		});

	}

});

/** end **/
	 

/** edit location **/
$(document).on("click",".edit-address",function(e){ 
	$("#editLocationform-button").click();
	var id = $(this).attr('address_id');
	$.ajax({
			url: 'function.php',
			type: 'POST',
			dataType: 'text',
			data:{function_name:'getEditAddressForm',address_id:id},
			success : function(text)
			{
				$('#autocomplete3').val($(text).find(".street").html());
				$('.postal_code').val($(text).find(".zip").html());
				$('.aptsuite').val($(text).find(".apt_suite").html());
				$('.street_number').val($(text).find(".street_number").html());
				$('#edit_address_id').val($(text).find(".address_id").html());
			},
		});
});
/** end **/


/** update location **/
$("#update-location-submit").click(function(){
	 
     $("#edit-address-result").append("<div class='loading1'><img src='images/loading.gif'></div>");
	var street_number = $(".street_number").val();
	var aptsuite      = $(".aptsuite").val();
	var street        = $("#autocomplete3").val();
	var id            = $("#edit_address_id").val();
	var zip           = $(".postal_code").val();

	
	if(zip=="")
	{
		zip = "00000";
	}

	if(street=="")
	{
		 $("#edit-address-result").html("<div class='warning'>Please fill the address</div>");
	}
	else
	{
		/** edit address ajax **/
		$.ajax({
			url: 'function.php',
			type: 'POST',
			dataType: 'text',
			data:{function_name:'getEditAddress',id:id,zip:zip,street:street,apt_suite:aptsuite,street_number:street_number},
			success : function(text)
			{
				if($(text).find(".success").html()!=="undefined")
				{
					$("#edit-address-result").append(text);
					
					setTimeout(function close(){$(".close").click(); $(".addlocationform").click();$("#edit-address-result").html('');}, 1000);
				
				}
				else
				{
					$("#edit-address-result").html(text);
				}			
			},
		});
		/** end **/
	}
});
/** end **/

/** add promocode modal **/
$("#add-promo").click(function(){
	$("#add-promo-result").html("");
	$("#add-promocode").click();
});
/** end **/



});

/** check status  **/
setInterval( function update() {
     	$("#page-result").html("<div class='loading-center'><img src='images/loading.gif'></div>");
	$.ajax({
			url: 'function.php',
			type: 'POST',
			dataType: 'text',
			data:{function_name:'AjaxRequestStatus',status:1},
			success : function(text)
			{
				$("#page-result").html('');
				/** nurse cancelled Request **/
				if(text=="6")	 
				{
					$("#np-error-trigger").click();				
				}
				/** end **/	
				/** Admin cancelled Request **/
				if(text=="7")	 
				{
					$("#admin-error-trigger").click();				
				}
				/** end **/	
				/** cancelled Request **/
				if(text=="5")	 
				{
					window.location.href='cancel_request.php';				
				}
				/** end **/
				/** Admin cancelled Request **/
				if(text=="10")	 
				{
					window.location.href='add-comment.php';				
				}
				/** end **/					
			},
		});
} , 40000 );
/** end **/

</script>


  
      <script type="text/javascript" src="//maps.google.com/maps/api/js?sensor=false"></script>
    <script type='text/javascript'>//<![CDATA[
	window.onload=function(){
	
	var locations = [
	    ['<?php echo $getaddress->street;?>',<?php echo $getaddress->latitude;?>, <?php echo $getaddress->longitude;?>, 1, "images/circle.png"],
	    ['Pediatric Specialist',<?php echo $getNurseLocation->location->latitude;?>, <?php echo $getNurseLocation->location->longitude;?>, 2, "images/loc-icon.png"]
	];
	
	
	 


	var map = new google.maps.Map(document.getElementById('map'), {
	    zoom: 14,
	    center: new google.maps.LatLng(<?php echo $getaddress->latitude;?>, <?php echo $getaddress->longitude;?>),
	    mapTypeId: google.maps.MapTypeId.ROADMAP
	});

	var infowindow = new google.maps.InfoWindow();

	var marker, i;

	for (i = 0; i < locations.length; i++) {
	    marker = new google.maps.Marker({
		position: new google.maps.LatLng(locations[i][1], locations[i][2]),
		icon: locations[i][4],
		map: map
	    });

	    google.maps.event.addListener(marker, 'click', (function (marker, i) {
		return function () {
		    infowindow.setContent(locations[i][0]);
		    infowindow.open(map, marker);
		}
	    })(marker, i));
	}
	}//]]> 

</script>


<!-- Reviews Modal -->
<div id="reviews-modal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="model-title">Reviews for <?php echo $name;?></h4>
        <br><span class="pointer"><img height="28px" src="images/stars.png"/><span class="span-text-modal"> <?php echo $average_rating." / ".$reviews;?> Reviews</span> </span>
      </div>
      <div class="modal-body">
     		<?php if(count($comments)){ foreach($comments as $comment){ ?>
		<div class="col-md-12">
			<div class="col-md-7"><p><?php if($comment->comment!=""){echo $comment->comment;}else{echo "No Comment Found";}?> <br> <?php echo $comment->author;?></p></div>		
			<div class="col-md-5 pull-right text-right"><img src="images/stars.png" height="20px;"/><?php if($comment->rating!=0){ echo "<b>".($comment->rating/10)."</b>";}else{ echo "<b>0</b>"; } ?></div>	
		</div>
		<?php }}else{?>
		No Reviews Found
		<?php }?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<!-- end of review modal -->



<!-- Resume Modal -->

 
 

<!-- Bio Modal -->
<div id="resumetrigger" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="model-title">Complete Biography</h4>
      </div>
      <div class="modal-body">
         <p><?php echo $bio;?></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<!-- end -->
 



<!-- Education Modal -->
<div id="educationtrigger" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="model-title">Education History</h4>
      </div>
      <div class="modal-body">
        <?php if(count($education)){$i=1; foreach($education as $educations){?>
		<p class="education"><?php echo $i.".  ".$educations->university;?>, <?php echo $educations->degree;?> <?php echo $educations->year;$i++;?> 			</p>
	<?php }}?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<!-- end -->


<!-- Trigger the modal with a button -->
<button type="button" class="btn btn-info btn-lg hide" id="admin-error-trigger" data-toggle="modal" data-target="#adminerror">Open Modal</button>

<!-- Admin cancelled Modal -->
<div id="adminerror" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="model-title">Request Cancelled</h4>
      </div>
      <div class="modal-body">
        <p>We are sorry, your request has been cancelled by admin.</p><br><br>
	<i>For medical emergencies, please dial 911 </i>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" onclick="window.location.href='cancel_request.php'">ok</button>
      </div>
    </div>

  </div>
</div>
<!-- end -->



<!-- Trigger the modal with a button -->
<button type="button" class="btn btn-info btn-lg hide" id="np-error-trigger" data-toggle="modal" data-target="#nperror">Open Modal</button>

<!-- Np error Modal -->
<div id="nperror" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="model-title">Request Cancelled</h4>
      </div>
      <div class="modal-body">
        <p>We are sorry, your request has been cancelled by Pediatric Specialist.</p><br><br>
	<i>For medical emergencies, please dial 911 </i>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" onclick="window.location.href='cancel_request.php'">ok</button>
      </div>
    </div>

  </div>
</div>
<!-- end -->
  
  


