<?php



//extract data from the post
//set POST variables
$url = 'https://www.keychainserver.net/keychain';
  


 
 
 
$sUrl = $url;
    $params = array('https' => array(
    'method' => 'POST',
'content' => 'email=darcy@darcyknapp.com&password=BirdChick1'
));

$ctx = stream_context_create($params);
$fp = @fopen($sUrl, 'rb', false, $ctx);
if (!$fp)
{
throw new Exception("Problem with $sUrl, $php_errormsg");
}

$response = @stream_get_contents($fp);
if ($response === false) 
{
throw new Exception("Problem reading data from $sUrl, $php_errormsg");
}



echo "<pre>"; print_r($response); echo "</pre>";


?>
