<?php require "function.php";logout(); // load main function file and then load header ?>

